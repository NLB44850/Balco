import { describe, expect, it } from "vitest";

import {
  decideReminder,
  type MaintenanceEvent,
  type PlantCareProfile,
  type WeatherSnapshot,
} from "../lib/reminders/reminder-engine";

const now = new Date("2026-09-23T18:00:00.000Z");

const plant: PlantCareProfile = {
  plantId: "tomatoes-cherry-01",
  displayName: "Tomates cerises",
  wateringIntervalHours: 48,
  rainSkipMm: 2,
  heatThresholdC: 30,
  frostThresholdC: 2,
  windThresholdKmh: 40,
  frostSensitive: true,
  allowedTaskTypes: ["watering", "observation", "protection"],
};

function weather(overrides: Partial<WeatherSnapshot> = {}): WeatherSnapshot {
  return {
    fetchedAt: now.toISOString(),
    timezone: "Europe/Paris",
    city: "Paris",
    latitude: 48.8566,
    longitude: 2.3522,
    current: {
      temperatureC: 22,
      apparentTemperatureC: 22,
      weatherCode: 0,
    },
    next12h: {
      precipitationMm: 0,
      precipitationProbabilityMax: 10,
      windGustKmhMax: 10,
    },
    today: {
      precipitationMm: 0,
      temperatureMinC: 14,
      temperatureMaxC: 24,
      windGustKmhMax: 10,
    },
    ...overrides,
  };
}

function event(type: MaintenanceEvent["type"], completedAt: string): MaintenanceEvent {
  return {
    id: `${type}-1`,
    plantId: plant.plantId,
    type,
    completedAt,
    source: "manual",
  };
}

describe("decideReminder", () => {
  it("returns no reminder when weather is stale", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather({ fetchedAt: "2026-09-23T10:00:00.000Z" }),
      now,
    });

    expect(result).toBeNull();
  });

  it("prioritizes protection for a hard frost", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather({ today: { precipitationMm: 0, temperatureMinC: -1, temperatureMaxC: 8, windGustKmhMax: 10 } }),
      now,
    });

    expect(result).toMatchObject({ action: "protect", taskType: "protection", priority: "urgent" });
  });

  it("suppresses watering when enough rain is expected", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather({ next12h: { precipitationMm: 6, precipitationProbabilityMax: 80, windGustKmhMax: 10 } }),
      now,
    });

    expect(result).toMatchObject({ action: "skip", taskType: "observation" });
    expect(result?.title).toContain("Pas besoin d’arroser");
  });

  it("asks for a soil check after the watering interval", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather(),
      now,
    });

    expect(result).toMatchObject({ action: "observe", taskType: "watering", priority: "normal" });
    expect(result?.body).toContain("terre");
  });

  it("raises watering priority in hot weather without ordering blind watering", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather({ today: { precipitationMm: 0, temperatureMinC: 20, temperatureMaxC: 34, windGustKmhMax: 10 } }),
      now,
    });

    expect(result).toMatchObject({ action: "observe", taskType: "watering", priority: "important" });
    expect(result?.body).toContain("vérifie");
  });

  it("limits repeated reminders to one per day", () => {
    const result = decideReminder({
      plant,
      history: [event("watering", "2026-09-20T10:00:00.000Z")],
      weather: weather(),
      lastReminderAt: "2026-09-23T12:00:00.000Z",
      now,
    });

    expect(result).toBeNull();
  });

  it("does not invent a watering need when there is no history", () => {
    const result = decideReminder({ plant, history: [], weather: weather(), now });

    expect(result).toBeNull();
  });
});
