import { int, mysqlTable, text, timestamp, varchar, double, uniqueIndex, index } from "drizzle-orm/mysql-core";

/** Core user table backing auth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: varchar("role", { length: 16 }).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const reminderProfiles = mysqlTable("reminder_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  enabled: int("enabled").default(0).notNull(),
  city: varchar("city", { length: 128 }).notNull().default("Paris"),
  latitude: double("latitude").notNull().default(48.8566),
  longitude: double("longitude").notNull().default(2.3522),
  timezone: varchar("timezone", { length: 64 }).notNull().default("Europe/Paris"),
  preferredHour: int("preferredHour").default(18).notNull(),
  preferredMinute: int("preferredMinute").default(30).notNull(),
  quietStartHour: int("quietStartHour").default(21).notNull(),
  quietEndHour: int("quietEndHour").default(9).notNull(),
  skipWateringWhenRainExpected: int("skipWateringWhenRainExpected").default(1).notNull(),
  maxNormalRemindersPerDay: int("maxNormalRemindersPerDay").default(1).notNull(),
  enabledPlantIds: text("enabledPlantIds"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ userUnique: uniqueIndex("reminder_profiles_user_unique").on(table.userId) }));

export const reminderPlants = mysqlTable("reminder_plants", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  plantId: varchar("plantId", { length: 128 }).notNull(),
  displayName: varchar("displayName", { length: 128 }).notNull(),
  profileJson: text("profileJson").notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ userPlantUnique: uniqueIndex("reminder_plants_user_plant_unique").on(table.userId, table.plantId), userIndex: index("reminder_plants_user_index").on(table.userId) }));

export const maintenanceEvents = mysqlTable("maintenance_events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventId: varchar("eventId", { length: 128 }).notNull(),
  plantId: varchar("plantId", { length: 128 }).notNull(),
  type: varchar("type", { length: 32 }).notNull(),
  completedAt: timestamp("completedAt").notNull(),
  source: varchar("source", { length: 32 }).notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ eventUnique: uniqueIndex("maintenance_events_user_event_unique").on(table.userId, table.eventId), userDateIndex: index("maintenance_events_user_date_index").on(table.userId, table.completedAt) }));

export const reminderDecisions = mysqlTable("reminder_decisions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  decisionKey: varchar("decisionKey", { length: 255 }).notNull(),
  plantId: varchar("plantId", { length: 128 }).notNull(),
  taskType: varchar("taskType", { length: 32 }).notNull(),
  action: varchar("action", { length: 32 }).notNull(),
  priority: varchar("priority", { length: 32 }).notNull(),
  payload: text("payload").notNull(),
  validUntil: timestamp("validUntil").notNull(),
  weatherFetchedAt: timestamp("weatherFetchedAt").notNull(),
  scheduledFor: timestamp("scheduledFor"),
  sentAt: timestamp("sentAt"),
  status: varchar("status", { length: 32 }).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ decisionUnique: uniqueIndex("reminder_decisions_user_key_unique").on(table.userId, table.decisionKey), userStatusIndex: index("reminder_decisions_user_status_index").on(table.userId, table.status) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ReminderProfile = typeof reminderProfiles.$inferSelect;
export type ReminderPlant = typeof reminderPlants.$inferSelect;
export type MaintenanceEvent = typeof maintenanceEvents.$inferSelect;
export type ReminderDecisionRow = typeof reminderDecisions.$inferSelect;
